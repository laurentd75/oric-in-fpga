Version 0.9 de travail / release working 

 Ce n'est pas encore un version fonctionnelle
mais c'est pour bientôt.
 It's not running but perhaps tomorrow ? ;-)

Merci à / Thanks to :
 + MikeJ de www.fpgaarcade.com pour avoir mis à disposition une 
   version de AY-3-8192 qui a permis de corriger la mienne et pour 
   le source du VIA 6522,
 + Gregory Estrade de www.torlus.com  (pour son aide et son libre accès
à son code vhdl)
 + Daniel Wallner pour le T65 (www.opencores.org)
